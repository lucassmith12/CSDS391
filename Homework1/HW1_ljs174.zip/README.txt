Hello dear TA! Thank you for looking over my submission. 
All exercises have been added and are functioning properly. 
The test suite is limited due to time contstraints, mostly just to show they work as intended.
(Also because I couldn't get grid data validation working in time (i'm still late))
Run the program without arguments to use the terminal interface or q to quit.
Run the program with a text file as an argument to run a set of commands.
The image of the program completing the testscmds.txt test case is in this zip as well.
Thanks!